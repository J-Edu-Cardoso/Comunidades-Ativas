// Configurações da aplicação
window.APP_CONFIG = {
    // Chave da API do Google Maps
    GOOGLE_MAPS_API_KEY: 'AIzaSyDj2HnAiZ-ukWC2wiQRJJphTgbNU8ogARo',
    // URL base da API do seu backend
    API_BASE_URL: 'http://localhost:3001/api' // Ajuste conforme necessário
};
